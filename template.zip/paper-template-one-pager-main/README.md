# On-pager Latex Template

## Building
```make all``` builds amd ```make clean``` cleas up temporary files. 
